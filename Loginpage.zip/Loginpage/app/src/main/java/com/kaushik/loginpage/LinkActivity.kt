package com.kaushik.loginpage

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class LinkActivity : AppCompatActivity() {

    private lateinit var amazon: ImageView
    private lateinit var flipkart: ImageView
    private lateinit var Ajio: ImageView
    private lateinit var myntra: ImageView
    private lateinit var meesho: ImageView
    private lateinit var snapdeal: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_link)

        amazon = findViewById(R.id.imageView1)
        myntra = findViewById(R.id.imageView2)
        snapdeal = findViewById(R.id.imageView3)
        flipkart = findViewById(R.id.imageView4)
        Ajio = findViewById(R.id.imageView5)
        meesho = findViewById(R.id.imageView6)

        amazon.setOnClickListener {
            val url = "https://www.amazon.com/"
            val uri = Uri.parse(url)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
        myntra.setOnClickListener {
            val url = "https://www.myntra.com/"
            val uri = Uri.parse(url)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
        snapdeal.setOnClickListener {
            val url = "https://www.snapdeal.com/"
            val uri = Uri.parse(url)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
        flipkart.setOnClickListener {
            val url = "https://www.flipkart.com/"
            val uri = Uri.parse(url)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
        Ajio.setOnClickListener {
            val url = "https://www.ajio.com/"
            val uri = Uri.parse(url)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
        meesho.setOnClickListener {
            val url = "https://www.meesho.com/"
            val uri = Uri.parse(url)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }

    }
}