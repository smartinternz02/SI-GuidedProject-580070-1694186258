package com.kaushik.loginpage

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class SetupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check if the app has already been set up
        val sharedPreferences = getSharedPreferences("login_prefs", Context.MODE_PRIVATE)
        val isSetup = sharedPreferences.getBoolean("is_setup", false)

        if (!isSetup) {
            // Initialize initial credentials (run only once)
            val editor = sharedPreferences.edit()
            editor.putString("username", "user")
            editor.putString("password", "1234")
            editor.putBoolean("is_setup", true)
            editor.apply()
        }

        // Finish this activity
        finish()
    }
}
